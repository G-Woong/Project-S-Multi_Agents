# MVP 아이디에이션 → Codex 구현 Starter Kit

짧은 아이디어 한 줄을 **Codex CLI에서 2~3시간 안에 구현 가능한 단일 `index.html`
MVP 설계 문서**로 바꿔 주는 실습 키트입니다. Claude Code가 5명의 전문 teammate를
돌려 요구사항을 확장·질문·설계하고, 그 결과를 `docs/`에 남깁니다. 교육생은 그
`docs/`를 Codex CLI로 가져가 실제 MVP를 완성합니다.

---

## 이 키트의 구성

```text
agent_teams/
├─ README.md          ← (지금 이 문서) 사용법
├─ practice2_guide.md ← 실습 2 교안 슬라이드 (수업에서 함께 봅니다)
├─ CLAUDE.md          ← Main 세션 오케스트레이션 규칙 (Claude Code가 자동으로 읽음)
├─ main_outputs.md    ← Main이 docs를 쓸 때 따르는 서식 (교육생은 안 읽어도 됩니다)
├─ agent_prompts/     ← 5명 teammate의 실행 프롬프트 (Main이 spawn 시 사용)
│  ├─ researcher.md · product_specifier.md · builder_planner.md
│  └─ reviewer.md · tester.md
└─ docs/              ← (실습 중 생성됨) 최종 MVP 설계 명세 = 진짜 산출물
   ├─ PROJECT_CONTEXT.md      # 아이디어 원문 + 확정 결정   ┐
   ├─ ROADMAP.md              # ← 여기부터 읽는다            ├ Main이 씀
   ├─ OPEN_DECISIONS.md       # 내가 답할 질문               ┘
   ├─ researcher/RESEARCH_REPORT.md      ┐
   ├─ product_specifier/MVP_SPEC.md      │
   ├─ builder/IMPLEMENTATION_PLAN.md     ├ teammate가 하나씩
   ├─ tester/TEST_PLAN.md                │
   ├─ reviewer/REVIEW_REPORT.md          ┘
   └─ codex_subagents/IMPLEMENTER.md · VERIFIER.md   ← Codex에 줄 지시서
```

- `docs/`는 실습을 시작하면 자동으로 만들어집니다. 처음엔 비어 있습니다.
- 최종 산출물은 `docs/` 전체이며, **정확히 10개의 md 파일**로 고정됩니다. 대화
  기록 없이 그 폴더만으로 이해·구현됩니다.
- `docs/`에서 **제일 먼저 여는 파일은 `ROADMAP.md`**입니다. 나머지 문서를 언제
  참조하는지가 그 안에 적혀 있습니다.

---

## 고정 제약 (반드시 알아둘 것)

- 최종 MVP는 **브라우저에서 바로 여는 단일 `index.html` 하나**입니다.
- HTML·CSS·JS를 한 파일에 임베드합니다. **React·Vue·npm·bundler·백엔드·DB·인증
  서버는 쓰지 않습니다.** 데이터는 정적 객체·mock·`localStorage`로 처리합니다.
- 규모는 **작게 고정**: 화면 1개 + 핵심 상호작용 1~2개 + 저장 정도. **Codex CLI
  1턴**(구현 subagent 1개 + 검증 subagent 1개)에 끝나는 크기, 총 2~3시간짜리
  실습입니다.

---

## 진행 흐름 (3 페이즈)

### 페이즈 1 — 아이디어 입력·질문
Claude Code 세션에 **아이디어를 5~10줄** 정도로 적어 보냅니다.
그러면 5 teammate가 조사·설계하고, 꼭 필요한 결정 몇 가지를 당신에게 질문합니다.
바로 답하기 애매한 선택지는 `docs/OPEN_DECISIONS.md`에 "대안 + 권장안 + 영향"과
함께 기록됩니다. 턴이 질문으로 끊기면 먼저 `docs/OPEN_DECISIONS.md`를 열어보세요.

> 입력 예시: "동네 러닝 크루 기록을 보는 웹앱을 원해요. 목록에서 크루를 고르면
> 오른쪽에 상세(코스·페이스·후기)가 보이고, 즐겨찾기를 저장했으면 해요. ..."

### 페이즈 2 — 선택 반영·명세 확정
`docs/OPEN_DECISIONS.md`를 읽고 선택/추가 의견을 적은 뒤 "반영해서 확정해줘"라고
말합니다. Main이 그 결정을 관련 teammate에 전파해 **제품 명세(MVP_SPEC)**·구현
계획·확인 계획을 최종(FINAL)으로 굳힙니다. 필요하면 이 과정을 몇 번 반복하며,
이때도 남은 질문은 `docs/OPEN_DECISIONS.md`에서 확인할 수 있습니다.

### 페이즈 3 — Codex 실행 교안 작성
명세가 확정되면 Main이 **`docs/ROADMAP.md`**(구현 절차 전체가 담긴 단일 지침)와
**`docs/codex_subagents/`**(구현·검증 subagent 생성 안내 2개)를 완성합니다.
여기까지가 Claude Code의 역할입니다. **제품 코드는 여기서 만들지 않습니다.**

각 페이즈 끝에서 Main이 "지금 상태 / 지금 할 일 / 다음 할 일"을 명시적으로 출력하니
그대로 따라가면 됩니다.

---

## 완성 후 — Codex CLI에서 구현

`docs/`가 완성되면 그 폴더를 Codex CLI로 가져가, 다음 3단계로 시작합니다.

```text
1) docs/codex_subagents/IMPLEMENTER.md 를 열어 생성 프롬프트를 Codex CLI에 붙여넣는다
2) docs/codex_subagents/VERIFIER.md 도 같은 방식으로 붙여넣는다
3) 마지막에 한 줄만 입력한다:
   ROADMAP.md를 전부 읽고서 방침을 따라 구현을 진행하라.
```

`ROADMAP.md`에는 구현 순서(STEP 0~3)와 완료 기준이 다 담겨 있어, 그대로 따라
하면 됩니다.

---

## 시작하기

Claude Code를 이 폴더에서 열고, **아이디어를 5~10줄 적어 보내면** 됩니다. 끝.
