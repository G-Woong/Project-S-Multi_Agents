# AGENTS.md - practice1 공통 지침 (Codex CLI 전용)

이 저장소는 "Galaxy Device Issue Triage Console" 실습(practice1)용 starter 다.
모든 Agent(Main / Backend / Frontend / Integration)는 아래 규칙을 지킨다.

## 실행 환경 규칙 (매우 중요)
- 이 실습은 **Codex CLI 에서만** 진행한다. Codex Desktop, 앱의 "새 작업 트리" 기능은 사용하지 않는다.
- worktree 와 branch 는 **사람이 터미널에서 `git worktree add` 로 직접, 한 번에** 만든다.
  - `git worktree add <경로> -b <branch> <시작 branch>` 형태로 작업 폴더와 branch 를 동시에 생성한다.
- 각 Agent 는 자기 worktree 폴더 안에서 `codex` 를 실행한 세션이다.
  자기 worktree 밖의 경로를 수정하지 않는다.
- Agent 는 새로운 worktree 를 스스로 만들거나 지우지 않는다
  (`git worktree add` / `git worktree remove` 는 사람이 실행한다).

## worktree / branch 구조 (tasks/acceptance.json 의 worktrees 가 단일 진실)

| 역할 | worktree 폴더 | branch | 시작 branch |
| --- | --- | --- | --- |
| Main | `main_codex_project` | `master` | - |
| Backend | `backend_worktree` | `backend-branch` | `master` |
| Frontend | `frontend_worktree` | `frontend-branch` | `master` |
| Integration | `integration_worktree` | `integration-branch` | `backend-branch` |

- Backend 와 Frontend 는 둘 다 `master` 에서 분기해 **동시에(병렬)** 구현한다.
- Integration 은 `backend-branch` 에서 분기해 `frontend-branch` 를 merge 하고,
  **이어서 통합 테스트와 승인 초안까지 같은 worktree 에서 마무리한다.**
  (별도의 tester worktree 는 없다.)

## 환경 규칙
- 외부 dependency 금지. `pip install`, `npm install`, FastAPI, Streamlit, Flask 등을 쓰지 않는다.
- 서버와 검증은 Python 표준 라이브러리만으로 동작해야 한다.
- Node.js 가 없어도 검증(scripts/*.py)이 가능해야 한다.
- 콘솔/로그 출력은 ASCII 우선, 상태값은 영어(PASS/FAIL/LOW/HIGH 등)로 쓴다.
  - 문서(.md)와 웹 UI(HTML) 에는 한글 설명을 넣어도 된다.

## 역할별 파일 권한 (tasks/acceptance.json 이 단일 진실)
- Backend: `server.py`, `docs/practice1/backend/report.md` 만 수정
- Frontend: `index.html`, `src/app.js`, `src/styles.css`, `docs/practice1/frontend/report.md` 만 수정
- Integration: 구현 파일 직접 수정 금지.
  `frontend-branch` merge + `docs/practice1/integration/` 아래 문서만 작성
  (`report.md`, `test_report.md`, `approval_draft.json`, 선택적으로 `audit.json`)
- 공통 금지: `data/issues.json`, `scripts/`, `tasks/acceptance.json` 수정 금지

## 검증/승인 규칙
- 검증 스크립트나 acceptance 기준을 바꿔서 억지로 통과시키지 않는다.
- approval draft 의 status 는 항상 `pending` 이다. 자동 승인 금지.
- 최종 merge 는 사람(Human) 이 Local master(`main_codex_project`) 에서만 한다.
- `git push` 는 하지 않는다. `git merge` 는 Integration 이 `frontend-branch` 를 합칠 때만 허용된다.

## 증거 위치 (저장소 내부)
- 모든 증거는 저장소 안 `docs/practice1/<role>/` 아래에 역할별로 분리 저장한다.
  - `docs/practice1/backend/report.md`
  - `docs/practice1/frontend/report.md`
  - `docs/practice1/integration/report.md` (merge 결과)
  - `docs/practice1/integration/test_report.md` (통합 테스트 결과)
  - `docs/practice1/integration/approval_draft.json` (status 는 항상 pending)
- 구현 전달은 Git branch + commit, 판단/검증 전달은 위 report/approval 파일이다.
- 별도 patch 파일은 만들지 않는다. Git diff 와 commit 이 이미 변경 증거다.
