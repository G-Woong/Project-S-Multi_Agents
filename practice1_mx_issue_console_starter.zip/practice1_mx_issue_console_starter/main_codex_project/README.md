# Galaxy Device Issue Triage Console - practice1 Starter

**Codex CLI** 에서 **Main / Backend / Frontend / Integration** 역할이 협업해
디바이스 이슈 분류 콘솔을 완성하는 실습입니다.

- worktree 와 branch 는 **터미널에서 `git worktree add` 로 사람이 직접, 한 번에** 만듭니다.
- Backend / Frontend 는 각자의 worktree 에서 **병렬**로 구현합니다.
- Integration 은 두 branch 를 합치고, **이어서 통합 테스트 + 승인 초안까지 한 자리에서** 마무리합니다.
- Human 은 증거(diff / report / approval)를 보고 **최종 merge** 를 판단합니다.

> Codex Desktop 은 이 실습에서 사용하지 않습니다. 전부 Codex CLI + 터미널로 진행합니다.

> 외부 패키지가 전혀 필요 없습니다. **Python 표준 라이브러리만** 사용합니다.
> `pip install` / `npm install` / FastAPI / Streamlit / Flask 를 쓰지 않습니다.

---

## 0. 폴더 구조

```
practice1_mx_issue_console_starter/
  main_codex_project/          <- 여기가 git 저장소가 됩니다 (Local master)
    README.md  AGENTS.md  index.html  server.py
    src/    (app.js, styles.css)
    data/   (issues.json)
    tasks/  (practice1_*.md, acceptance.json)
    scripts/(check_api.py, check_dom.py, audit.py)
    docs/practice1/            <- 저장소 내부 증거함 (역할별로 분리)
      backend/report.md
      frontend/report.md
      integration/report.md  integration/test_report.md
      integration/approval_draft.json  (integration/audit.json 은 선택)
```

실습이 끝나면 상위 폴더는 이렇게 됩니다.

```
practice1_mx_issue_console_starter/
  main_codex_project/     branch: master
  backend_worktree/       branch: backend-branch
  frontend_worktree/      branch: frontend-branch
  integration_worktree/   branch: integration-branch
```

---

## 1. 이 실습의 목적

- Galaxy Device Issue Triage Console 을 만든다.
- Backend Agent 와 Frontend Agent 를 **병렬 worktree** 에서 동시에 구현한다.
- Integration 이 두 결과를 합치고, **같은 worktree 에서 이어서** 통합 검증 + 승인 초안을 만든다.
- Human 이 증거를 보고 merge 를 판단한다.

---

## 2. 실행 방법 (starter 확인)

`main_codex_project` 로 이동해서:

```powershell
# 1) git 저장소 초기화 (starter 에는 .git 이 없습니다. 기본 branch = master)
git init -b master
git add .
git commit -m "chore(practice1): import starter"

# 2) 서버 실행 (Windows: py, macOS/Linux: python3)
py server.py
```

브라우저에서 접속:

```
http://127.0.0.1:8000
```

포트를 바꾸려면:

```powershell
py server.py --host 127.0.0.1 --port 8080
```

> `git init -b master` 의 `-b master` 가 안 되는 구버전 git 이면:
> `git init` 후 `git branch -m master` 로 브랜치 이름을 master 로 맞추세요.

---

## 3. 초기 검증 (일부 FAIL 이 정상입니다)

starter 상태에서 검증 스크립트를 돌리면:

```powershell
py scripts/check_api.py   # FAIL 예상 (triage 규칙 미구현)
py scripts/check_dom.py   # FAIL 예상 (카드/필터/P0 강조 미구현)
py scripts/audit.py       # implementationRisk = HIGH 예상
```

**이것은 의도된 상태입니다.**
- `GET /api/health`, `GET /api/issues` 는 정상 동작합니다.
- `POST /api/triage` 는 일부러 미완성이라 `check_api` 가 FAIL 합니다.
- 프론트엔드 카드/필터/summary 가 미완성이라 `check_dom` 이 FAIL 합니다.

즉, Backend / Frontend Agent 가 **채워야 할 목표 지점**이 명확히 보이도록 설계되어 있습니다.

---

## 4. worktree 생성 (사람이 터미널에서 직접)

`main_codex_project` 안에서 실행합니다. `-b` 옵션 덕분에 **작업 폴더와 branch 가 한 번에** 만들어집니다.

```powershell
# Backend / Frontend 는 master 에서 병렬 분기
git worktree add ..\backend_worktree  -b backend-branch  master
git worktree add ..\frontend_worktree -b frontend-branch master

git worktree list
```

각 작업장에서 Codex CLI 를 실행합니다.

```powershell
cd ..\backend_worktree
codex
```

| 역할 | worktree 폴더 | branch | 시작 branch | 하는 일 |
| --- | --- | --- | --- | --- |
| Backend | `backend_worktree` | `backend-branch` | `master` | `server.py` 분류 로직 구현 |
| Frontend | `frontend_worktree` | `frontend-branch` | `master` | 대시보드 UI 구현 |
| Integration | `integration_worktree` | `integration-branch` | `backend-branch` | `frontend-branch` merge + 통합 검증 + 승인 초안 |

Backend 와 Frontend 는 **둘 다 master 에서 독립적으로** 시작해 동시에 진행합니다.

Backend / Frontend commit 이 끝난 뒤 Integration worktree 를 만듭니다.

```powershell
cd ..\main_codex_project
git worktree add ..\integration_worktree -b integration-branch backend-branch

cd ..\integration_worktree
codex
```

Final merge (사람 승인 후, Local master 에서만):

```powershell
cd ..\main_codex_project
git switch master
git merge --no-ff integration-branch -m "merge(practice1): complete parallel issue console implementation"
py scripts/check_api.py
py scripts/check_dom.py
py scripts/audit.py
py server.py
```

실습 정리(선택):

```powershell
git worktree remove ..\backend_worktree
git worktree remove ..\frontend_worktree
git worktree remove ..\integration_worktree
git worktree list
```

---

## 5. 최종 완성 상태 (목표)

- `py scripts/check_api.py`  -> PASS
- `py scripts/check_dom.py`  -> PASS
- `py scripts/audit.py`      -> implementationRisk = LOW
- 브라우저에서 이슈 카드가 표시됨 / P0·P1·P2 summary 표시 / 필터 동작 / P0 카드 강조
- approval draft 의 status 는 항상 `pending`, recommendation 은 `approve_candidate`

---

## 6. 주의사항

- Backend 는 `server.py` + `docs/practice1/backend/report.md` 만 수정한다.
- Frontend 는 `index.html`, `src/app.js`, `src/styles.css` + `docs/practice1/frontend/report.md` 만 수정한다.
- Integration 은 구현 파일을 직접 고치지 않고, merge + `docs/practice1/integration/` 아래 문서만 작성한다.
- `data/issues.json`, `scripts/`, `tasks/acceptance.json` 은 수정 금지.
- approval draft 는 항상 pending. 자동 승인 없음.
- 최종 merge 는 사람이 Local master 에서 한다. `git push` 는 하지 않는다.
- 같은 branch 를 두 worktree 에서 동시에 checkout 하지 않는다. 재시도는 `-r2` 같은 새 이름으로 만든다.

---

## 7. 스크립트 요약

| 스크립트 | 역할 |
| --- | --- |
| `check_api.py` | server.py 를 임의 포트로 띄워 API 검증 (PASS/FAIL, 파일 미생성) |
| `check_dom.py` | index.html/app.js/styles.css 정적 검증 (PASS/FAIL, 파일 미생성) |
| `audit.py` | check_api + check_dom -> implementationRisk 산출. `--out <path>` 로 audit.json 저장(Integration 선택) |

report 와 approval 은 스크립트가 아니라 **Agent 가 직접** `docs/practice1/<role>/` 아래에 작성합니다.
patch 파일은 만들지 않습니다 — Git diff 와 commit 이 이미 변경 증거입니다.
