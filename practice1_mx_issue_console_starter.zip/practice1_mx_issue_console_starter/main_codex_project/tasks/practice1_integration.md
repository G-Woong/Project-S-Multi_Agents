# practice1 - Integration Agent 작업 명세 (merge + 통합 테스트 + 승인 초안)

## 작업장
- worktree 폴더: `integration_worktree`
- branch: `integration-branch` (시작 branch `backend-branch`)
- 이 worktree 는 사람이 터미널에서 아래 명령으로 이미 만들어 두었다.

```powershell
git worktree add ..\integration_worktree -b integration-branch backend-branch
```

시작점은 `master` 가 아니라 **Backend 구현이 끝난 `backend-branch`** 다.
별도의 tester worktree 는 없다. **merge 부터 테스트, 승인 초안까지 이 worktree 에서 전부 끝낸다.**

## 목표
Backend 결과(`backend-branch`) 위에서 Frontend 결과(`frontend-branch`)를 합치고,
합쳐진 통합본이 전체 검증을 통과하는지 확인한 뒤, 승인 초안까지 남긴다.

## 순서

### 1) 시작 상태 확인 (아직 아무것도 바꾸지 않는다)
- HEAD 가 `backend-branch` 최신 commit 과 같은가
- `frontend-branch` 가 존재하는가
- working tree 가 clean 한가

### 2) 병합
- `git merge --no-ff frontend-branch`
- 충돌이 나면 임의로 해결하지 말고 중단한다 (충돌은 보통 누군가 범위 밖 파일을 건드린 신호).

### 3) 통합 검증 (예전 Tester 단계가 여기로 통합됨)
- `py scripts/check_api.py`
- `py scripts/check_dom.py`
- `py scripts/audit.py --out docs/practice1/integration/audit.json`  (audit.json 은 선택)
- 결과를 조작하지 않는다. 실패하면 실패로 기록한다.

### 4) 증거 문서 작성
- `docs/practice1/integration/report.md`
  - merge 대상, 충돌 유무, 변경 파일 범위
- `docs/practice1/integration/test_report.md`
  - 실제 PASS/FAIL, implementationRisk, 실패 원인, 남은 리스크
- `docs/practice1/integration/approval_draft.json`
  - status 는 항상 `"pending"`
  - 모두 통과하면 recommendation 은 `"approve_candidate"`
  - 하나라도 실패하면 recommendation 은 `"hold"`

## 규칙 (acceptance.json)
- allowedFiles: `docs/practice1/integration/report.md`, `docs/practice1/integration/test_report.md`,
  `docs/practice1/integration/approval_draft.json`, `docs/practice1/integration/audit.json`
- forbiddenFiles: server.py, index.html, src/app.js, src/styles.css, data/issues.json, scripts/, tasks/acceptance.json
- 구현 파일(server.py / 프론트 3파일)을 **직접 수정하지 않는다.**
  테스트가 실패하면 담당 역할(Backend/Frontend) branch 로 되돌린다.

## 마무리 (증거 + commit)
merge commit 과 문서 commit 은 분리한다.

```powershell
# integration_worktree 터미널에서 직접 실행할 경우

# (1) Frontend 병합
git merge --no-ff frontend-branch -m "merge(practice1): merge frontend-branch into integration-branch"

# (2) 통합 검증
py scripts/check_api.py
py scripts/check_dom.py
py scripts/audit.py

# (3) 증거 문서만 stage 하고 별도 commit
git add docs/practice1/integration/
git commit -m "docs(practice1): record integration and test evidence"

git status --short
git log --oneline --graph -5
```

- master merge 와 push 는 금지한다. 최종 merge 는 사람이 `main_codex_project` 에서 한다.
