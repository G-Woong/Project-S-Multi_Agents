# practice1 - Main (Orchestrator) 작업 명세

## 역할
Codex CLI 로 전체 파이프라인을 분해하고 조율한다. 코드는 직접 짜지 않는다.
증거를 모으고, 사람(Human)이 최종 merge 를 판단하도록 돕는다.
작업 위치는 `main_codex_project` (branch `master`) 다.

## 순서
1. 작업 분해
   - Backend: server.py 의 분류 로직(classify_issue, POST /api/triage)
   - Frontend: index.html / src/app.js / src/styles.css 의 대시보드
   - Integration: 두 branch 통합 + 전체 검증 + 승인 초안 (예전 Tester 단계 포함)
2. 역할별 작업장은 **사람이 터미널에서** `git worktree add` 로 만든다.
   Codex Desktop 의 "새 작업 트리" 기능은 사용하지 않는다.

   ```powershell
   git worktree add ..\backend_worktree     -b backend-branch     master
   git worktree add ..\frontend_worktree    -b frontend-branch    master
   # Backend commit 이 끝난 뒤에
   git worktree add ..\integration_worktree -b integration-branch backend-branch
   ```

3. 각 Agent 의 allowedFiles / forbiddenFiles 확인 (tasks/acceptance.json 이 단일 진실)
   - Backend: server.py (+ docs/practice1/backend/report.md)
   - Frontend: index.html/app.js/styles.css (+ docs/practice1/frontend/report.md)
   - Integration: docs/practice1/integration/ 아래 문서만
4. 병렬 실행 순서
   - Backend, Frontend 는 둘 다 master 에서 독립적으로 시작해 동시에 구현한다.
   - 각 Agent 는 자기 worktree 에서 테스트 통과 후 report 작성 + commit 까지 수행한다.
5. 통합 + 검증 (한 worktree 에서 연속 진행)
   - Integration: `backend-branch` 에서 `integration-branch` 분기 -> `frontend-branch` 를 `--no-ff` merge
   - 이어서 check_api / check_dom / audit 를 모두 실행한다.
   - 이어서 test_report.md 와 approval_draft.json 을 작성한다.
   - approval draft 의 status 는 항상 pending. recommendation 은 참고만.
6. 최종 리뷰
   - Main Reviewer 는 Local master 에서 branch diff / report / approval draft / Git graph 만 읽고 판단을 제안한다.
7. 사람 승인 전에는 절대 master 로 merge 하지 않는다.

## Main 이 읽는 증거 명령 (읽기 전용)

```powershell
git worktree list
git branch -a

git diff --name-status master..backend-branch
git diff --name-status master..frontend-branch
git diff --name-status backend-branch..integration-branch

git show integration-branch:docs/practice1/integration/test_report.md
git show integration-branch:docs/practice1/integration/approval_draft.json
git log --oneline --graph --all
```

## 금지
- 코드/문서 직접 수정, git add/commit/merge/push (Main 은 판단만 제안)
- 사람 승인 없는 최종 merge 금지
- Codex Desktop 기능 사용 금지 (worktree 는 CLI 에서 사람이 만든다)
- scripts/ 와 tasks/acceptance.json 수정 금지
